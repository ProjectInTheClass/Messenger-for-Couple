//
//  Latte_Chat.swift
//  Latte
//
//  Created by 이현지 on 10/05/2019.
//  Copyright © 2019 이현지. All rights reserved.
//

import UIKit

var MyMessages:[Message] = []
var YourMessages:[Message] = []

struct Time{
    let Hour: Int
    let Minute: Int
    
    init(){
        self.Hour = 0
        self.Minute = 0
    }
    
    init(Hour: Int, Minute: Int){
        self.Hour = Hour
        self.Minute =  Minute
    }
}

struct Message{
    let Content: String
    let SendDay: Date
    let SendTime: Time
    
    init(Content: String, SendDay: Date, SendTime: Time){
        self.Content = Content
        self.SendDay = SendDay
        self.SendTime = SendTime
    }
}

struct Emoticon{
    let Emoticon: String
    let SendDay: Date
    let SendTime: Time
    
    init(Emoticon: String, SendDay: Date, SendTime: Time){
        self.Emoticon = Emoticon
        self.SendDay = SendDay
        self.SendTime = SendTime
    }
}


class Latte_Chat: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
