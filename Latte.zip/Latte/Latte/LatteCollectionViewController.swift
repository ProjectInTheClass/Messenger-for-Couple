//
//  LatteCollectionViewController.swift
//  Latte
//
//  Created by 이현지 on 09/05/2019.
//  Copyright © 2019 이현지. All rights reserved.
//

import UIKit

class LatteCollectionViewCell: UICollectionViewCell{
    
    @IBOutlet weak var oneimage: UIImageView!

    @IBOutlet weak var onelabel: UILabel!
}

class LatteCollectionViewCell2: UICollectionViewCell{
    
    @IBOutlet weak var onePhoto: UIImageView!
}
