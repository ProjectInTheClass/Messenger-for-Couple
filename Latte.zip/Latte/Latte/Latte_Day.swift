//
//  Latte_Day.swift
//  Latte
//
//  Created by 이현지 on 10/05/2019.
//  Copyright © 2019 이현지. All rights reserved.
//

import UIKit

struct Date{
    var Year: Int
    var Month: Int
    var Day: Int
    
    init(){
        self.Year = 0
        self.Month = 0
        self.Day = 0
    }
    
    init(Year: Int, Month: Int, Day: Int){
        self.Year = Year
        self.Month = Month
        self.Day = Day
    }
}

struct LoveDay{
    var TrueLoveDays: Int
    var RealDays: Int
    let StartDate: Date
    
    init(){
        TrueLoveDays = 0
        RealDays = 0
        StartDate = Date.init()
    }
    
    init(TrueLoveDays: Int, RealDays: Int, StartDate: Date){
        self.TrueLoveDays = TrueLoveDays
        self.RealDays = RealDays
        self.StartDate = StartDate
    }
    
    mutating func Calculate(StartDate: Date, Today: Date) -> Date{
        var CalDays: Date = Date.init()
        /*
         calculate real days
         */
        CalDays.Year = Today.Year - StartDate.Year
        CalDays.Month = Today.Month - StartDate.Month
        CalDays.Day = Today.Day - StartDate.Day
        
        return CalDays
    }
}


class Latte_Day: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


