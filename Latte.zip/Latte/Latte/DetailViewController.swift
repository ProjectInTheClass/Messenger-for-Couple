//
//  ViewController.swift
//  Latte
//
//  Created by 이현지 on 18/04/2019.
//  Copyright © 2019 이현지. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //UI 업데이트
        //print(NowDay.Year)
    }

}

