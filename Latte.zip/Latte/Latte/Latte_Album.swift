//
//  Latte_Album.swift
//  Latte
//
//  Created by 이현지 on 10/05/2019.
//  Copyright © 2019 이현지. All rights reserved.
//

import UIKit

let images = [["like.png","like.png","like.png"],["이현지.jpg","이현지-2.jpg","이현지.jpg"],["이현지-2.jpg","이현지-2.jpg","이현지.jpg"]]

class Latte_Album: UIViewController, UICollectionViewDataSource {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //section의 수
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mycell", for: indexPath) as! LatteCollectionViewCell
        
        let nowImage = images[indexPath.row][0]
        
        cell.oneimage.image = UIImage(named: nowImage)
        cell.onelabel.text = images[indexPath.row][0]
        // Configure the cell
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //if segue.identifier == "albums" {
            let photosVC = segue.destination as! Latte_Photos
            let cell = sender as! LatteCollectionViewCell
            
            for i in 0...images.count {
                if images[i][0] == cell.onelabel.text{
                    for j in 0...images[i].count {
                        photosVC.photos.append(images[i][j])
                    }
                }
            }
        //}
    }
}

class Latte_Photos: UIViewController, UICollectionViewDataSource {
    
    var photos : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    //section의 수
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mycell2", for: indexPath) as! LatteCollectionViewCell2
        
        let nowImage = photos[indexPath.row]
        
        cell.onePhoto.image = UIImage(named: nowImage)
        // Configure the cell
        
        return cell
    }
}
