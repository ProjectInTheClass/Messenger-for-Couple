//
//  CalendarViewController.swift
//  CalenderPractice
//
//  Created by sw_studio1 on 2019. 5. 10..
//  Copyright © 2019년 sw_studio1. All rights reserved.
//

import UIKit
import FSCalendar

class CalendarViewController: UIViewController {

    fileprivate weak var calendar : FSCalendar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let calendar = FSCalendar(frame: CGRect(x:50,y:200,width:320,height:300))

        calendar.dataSource = self
        calendar.delegate = self
        
        calendar.register(FSCalendarCell.self, forCellReuseIdentifier: "Cell")
        
        calendar.appearance.headerTitleColor = UIColor.brown
        calendar.appearance.todayColor = UIColor.lightGray
        //calendar.appearance.titleDefaultColor = UIColor.green
        //calendar.appearance.subtitleDefaultColor = UIColor.green
        calendar.appearance.titleDefaultColor = UIColor.black
        
        view.addSubview(calendar)
        
        self.calendar = calendar
        // Do any additional setup after loading the view.
    }
    
}

extension CalendarViewController : FSCalendarDataSource, FSCalendarDelegate{
    /*
     //
    func calendar(_ calendar: FSCalendar, titleFor date: Date) -> String? {
        return "maxcodes.io"
    }
    func calendar(_ calendar: FSCalendar, subtitleFor date: Date) -> String? {
        return "subtitle"
    }*/
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell = calendar.dequeueReusableCell(withIdentifier: "Cell", for: date, at: position)
        return cell
    }
}
